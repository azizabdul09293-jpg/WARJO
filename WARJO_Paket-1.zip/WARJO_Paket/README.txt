WARJO — PAKET AWAL ANDROID + PROMPT

Isi:
- PROMPT_WARJO.txt: prompt lengkap proyek.
- app/: source Android Studio (Kotlin WebView) dengan halaman awal WARJO.

PENTING:
Ini adalah SOURCE PROJECT awal, BUKAN APK siap instal. Lingkungan ini tidak memiliki Android SDK/Gradle untuk membangun APK.
Fitur akun, menu, dan checkout saat ini hanya demo lokal di perangkat. Jangan gunakan password penting. Belum ada backend online, sinkronisasi owner-pelanggan, pembayaran QR asli, atau fitur antrean online.

Cara membuat APK:
1. Buka Android Studio di komputer.
2. Pilih Open, lalu pilih folder WARJO_Paket.
3. Tunggu Gradle Sync selesai.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug akan dibuat di app/build/outputs/apk/debug/app-debug.apk.

Untuk penggunaan sungguhan, tahap berikutnya adalah menambahkan backend online dan autentikasi aman sebelum dipublikasikan.
